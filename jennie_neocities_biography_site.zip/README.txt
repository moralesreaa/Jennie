JENNIE BIOGRAPHY ARCHIVE — PAQUETE PARA NEOCITIES

1) Descomprime el ZIP.
2) Entra en Neocities y abre Edit Site / Dashboard.
3) Sube estos elementos:
   index.html
   style.css
   images/jennie-archive-artwork.png
4) Tu página principal es index.html.

EDICIÓN:
- Textos y secciones: index.html
- Colores y animaciones: style.css
- Imágenes: carpeta images/

NOTA SOBRE IMÁGENES:
El arte incluido fue creado para este proyecto. Para añadir fotos reales de Jennie, sube a images/ solamente fotografías que tengas permiso de utilizar y sustituye el nombre del archivo en el código.

BIOGRAFÍA:
Incluye nacimiento en 1996, etapa de estudios en Nueva Zelanda, regreso a Corea en 2010, debut con BLACKPINK en 2016, SOLO (2018), You & Me (2023), nueva etapa con ODD ATELIER, Mantra (2024) y el álbum Ruby (2025).
